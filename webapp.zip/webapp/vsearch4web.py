from flask import Flask, render_template, request, redirect
from vsearch import search4letter
app = Flask(__name__)
@app.route('/')
def hello () -> '302':
    return redirect('/entry')

@app.route('/search4', methods=['post'])
def do_search() -> 'html':
    #return str(search4letter('life, the universe, and everything', 'eiru,!'))
    phrase = request.form['phrase']
    letters = request.form['letters']
    results = str(search4letter(phrase,letters))
    return render_template('results.html',
    						the_title='Welcome to search4letters on the web!',
    						the_phrase= phrase,
    						the_letters = letters,
    						the_results = results,)

@app.route('/entry')
def entry_page() -> 'html':
	return render_template('entry.html',
							the_title='Welcome to search4letters on the web!')

if __name__ == '__main__':
	app.run(debug=True)

